from django.core.exceptions import ValidationError


def validate_menu_categories(value):
    required_categories = ["Appetizers", "Main Course", "Desserts"]
    if not all(category in value for category in required_categories):
        raise ValidationError('The menu must include each of the categories "Appetizers", "Main Course", "Desserts".')