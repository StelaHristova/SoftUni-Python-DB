import os
import django
from django.db.models import Count

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
from main_app.models import TennisPlayer, Tournament, Match


# Create queries within functions
def get_tennis_players(search_name=None, search_country=None):

    if search_name is None and search_country is None:
        return ''

    players = []

    if search_name is not None and search_country is not None:
        players = TennisPlayer.objects.filter(
            full_name__icontains=search_name,
            country__icontains=search_country
        ).order_by('ranking')

    elif search_name is not None and search_country is None:
        players = TennisPlayer.objects.filter(
            full_name__icontains=search_name
        ).order_by('ranking')

    elif search_name is None and search_country is not None:
        players = TennisPlayer.objects.filter(
            country__icontains=search_country
        ).order_by('ranking')

    if not players.exists():
        return ''

    players_info = '\n'.join(
        f'Tennis Player: {p.full_name}, country: {p.country}, ranking: {p.ranking}'
        for p in players
    )

    return players_info


def get_top_tennis_player() -> str:
    top_tennis_player = TennisPlayer.objects\
        .get_tennis_players_by_wins_count()\
        .first()

    if not top_tennis_player:
        return f''

    return f'Top Tennis Player: {top_tennis_player.full_name} with {top_tennis_player.wins_count} wins.'


def get_tennis_player_by_matches_count() -> str:
    best_tennis_player = TennisPlayer.objects\
        .prefetch_related('tennis_player_matches')\
        .annotate(matches_count=Count('tennis_player_matches'))\
        .filter(matches_count__gt=0)\
        .order_by(
            '-matches_count',
            'ranking'
        )\
        .first()

    if not best_tennis_player:
        return ''

    return f'Tennis Player: {best_tennis_player.full_name} with {best_tennis_player.matches_count} matches played.'

